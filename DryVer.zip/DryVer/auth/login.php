<?php
session_start();
// Jika pengguna sudah login, arahkan ke dashboard
if (isset($_SESSION['username'])) {
    header('Location: ../index.php');
    exit();
}

include '../config/db.php'; // Pastikan path ke db.php sudah benar, relatif dari auth/

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error_message = "Username dan password harus diisi.";
    } else {
        if (!isset($conn) || $conn->connect_error) {
            $error_message = "Koneksi database gagal: " . ($conn->connect_error ?? "Variabel \$conn tidak terdefinisi.");
        } else {
            // Menggunakan prepared statement untuk mencegah SQL Injection
            $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
            if ($stmt) {
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $hashed_password = $row['password'];

                    // Verifikasi password
                    if (password_verify($password, $hashed_password)) {
                        $_SESSION['username'] = $username;
                        header('Location: ../index.php');
                        exit();
                    } else {
                        $error_message = "Password salah.";
                    }
                } else {
                    $error_message = "Username tidak ditemukan.";
                }
                $stmt->close();
            } else {
                $error_message = "Gagal menyiapkan statement: " . $conn->error;
            }
            $conn->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DryVer | Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Menggunakan variabel CSS yang sama dari dashboard */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        :root {
            --primary-blue: #0A2E49;
            --light-blue: #2A688F;
            --accent-yellow: #B8860B;
            --background-gradient-start: #f0f2f5;
            --background-gradient-end: #e0e2e5;
            --card-background: rgba(255, 255, 255, 0.7);
            --text-dark: #333;
            --text-light: #fff;
            --border-light: rgba(255, 255, 255, 0.3);
            --shadow-light: rgba(0, 0, 0, 0.08);
            --shadow-strong: rgba(0, 0, 0, 0.15);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start), var(--background-gradient-end));
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            color: var(--text-dark);
            overflow: hidden; /* Prevent scroll if content overflows */
        }

        .login-container {
            background: var(--card-background);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 10px 30px var(--shadow-strong);
            text-align: center;
            width: 100%;
            max-width: 400px;
            border: 1px solid var(--border-light);
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-header {
            margin-bottom: 30px;
        }

        .login-header .logo {
            width: 60px;
            height: 60px;
            background-color: var(--primary-blue);
            color: var(--text-light);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            font-size: 2.5rem;
            margin: 0 auto 15px;
        }

        .login-header h2 {
            margin: 0;
            color: var(--primary-blue);
            font-size: 2.2rem;
            font-weight: 700;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--primary-blue);
            font-weight: 600;
            font-size: 0.95rem;
        }

        .form-group input {
            width: calc(100% - 20px); /* Adjust for padding */
            padding: 12px 10px;
            border: 1px solid var(--border-light);
            border-radius: 10px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.4);
            color: var(--text-dark);
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--light-blue);
            box-shadow: 0 0 0 3px rgba(42, 104, 143, 0.2);
            background: rgba(255, 255, 255, 0.6);
        }

        .form-group input::placeholder {
            color: #888;
        }

        .btn-login {
            background-color: var(--primary-blue);
            color: var(--text-light);
            border: none;
            padding: 15px 25px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: 600;
            width: 100%;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn-login:hover {
            background-color: var(--light-blue);
            transform: translateY(-2px);
        }

        .error-message {
            color: #dc3545;
            background-color: rgba(255, 99, 132, 0.1);
            border: 1px solid #dc3545;
            padding: 10px;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 0.9em;
        }

        .forgot-password,
        .register-link {
            display: block;
            margin-top: 15px;
            color: var(--light-blue);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }

        .forgot-password:hover,
        .register-link:hover {
            color: var(--primary-blue);
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo"><i class="fas fa-seedling"></i></div>
            <h2>Selamat Datang di DryVer</h2>
        </div>
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Masukkan username Anda" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Masukkan password Anda" required>
            </div>
            <button type="submit" class="btn-login">Login</button>
        </form>
        <?php if ($error_message): ?>
            <div class="error-message">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>
        <a href="#" class="forgot-password">Lupa Password?</a>
        <a href="register.php" class="register-link">Belum punya akun? Daftar di sini</a>
    </div>
</body>
</html>