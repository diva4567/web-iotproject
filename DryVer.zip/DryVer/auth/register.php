<?php
include '../config/db.php';

$error_message = ''; // Mengubah nama variabel dari $error menjadi $error_message agar konsisten dengan login.php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Tambahkan pengecekan koneksi database terlebih dahulu
    if (!isset($conn) || $conn->connect_error) {
        $error_message = "Koneksi database gagal: " . ($conn->connect_error ?? "Variabel \$conn tidak terdefinisi.");
    } else if (empty($username) || empty($password)) { // Gabungkan validasi kosong di sini
        $error_message = "Username dan password harus diisi.";
    } else {
        // Cek apakah username sudah ada
        $check_stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        if ($check_stmt === false) {
            $error_message = "Gagal menyiapkan pernyataan cek username: " . $conn->error;
        } else {
            $check_stmt->bind_param("s", $username);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();

            if ($check_result->num_rows > 0) {
                $error_message = "Username sudah digunakan. Silakan pilih username lain.";
            } else {
                // Hash password sebelum menyimpan
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Insert pengguna baru
                $insert_stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
                if ($insert_stmt === false) {
                    $error_message = "Gagal menyiapkan pernyataan insert: " . $conn->error;
                } else {
                    $insert_stmt->bind_param("ss", $username, $hashed_password);

                    if ($insert_stmt->execute()) {
                        // Redirect ke halaman login setelah berhasil daftar
                        header("Location: login.php?registration_success=true");
                        exit();
                    } else {
                        $error_message = "Terjadi kesalahan saat mendaftar: " . $insert_stmt->error;
                    }
                    $insert_stmt->close();
                }
            }
            $check_stmt->close();
        }
    }
    // Tidak perlu $conn->close() di sini karena bisa jadi koneksi akan digunakan di bagian HTML
    // atau PHP akan menutupnya secara otomatis di akhir skrip.
}
// Tidak perlu $conn->close() di akhir jika Anda akan menampilkan HTML,
// PHP akan menutup koneksi secara otomatis di akhir skrip.
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DryVer | Registrasi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Menggunakan variabel CSS yang sama dari dashboard dan login */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        :root {
            --primary-blue: #0A2E49;
            --light-blue: #2A688F;
            --accent-yellow: #B8860B;
            --background-gradient-start: #f0f2f5;
            --background-gradient-end: #e0e2e5;
            --card-background: rgba(255, 255, 255, 0.7);
            --text-dark: #333;
            --text-light: #fff;
            --border-light: rgba(255, 255, 255, 0.3);
            --shadow-light: rgba(0, 0, 0, 0.08);
            --shadow-strong: rgba(0, 0, 0, 0.15);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start), var(--background-gradient-end));
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            color: var(--text-dark);
            overflow: hidden;
        }

        .register-container {
            background: var(--card-background);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 10px 30px var(--shadow-strong);
            text-align: center;
            width: 100%;
            max-width: 400px;
            border: 1px solid var(--border-light);
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .register-header {
            margin-bottom: 30px;
        }

        .register-header .logo {
            width: 60px;
            height: 60px;
            background-color: var(--primary-blue);
            color: var(--text-light);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            font-size: 2.5rem;
            margin: 0 auto 15px;
        }

        .register-header h2 {
            margin: 0;
            color: var(--primary-blue);
            font-size: 2.2rem;
            font-weight: 700;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--primary-blue);
            font-weight: 600;
            font-size: 0.95rem;
        }

        .form-group input {
            width: calc(100% - 20px); /* Adjust for padding */
            padding: 12px 10px;
            border: 1px solid var(--border-light);
            border-radius: 10px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.4);
            color: var(--text-dark);
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--light-blue);
            box-shadow: 0 0 0 3px rgba(42, 104, 143, 0.2);
            background: rgba(255, 255, 255, 0.6);
        }

        .form-group input::placeholder {
            color: #888;
        }

        .btn-register {
            background-color: var(--primary-blue);
            color: var(--text-light);
            border: none;
            padding: 15px 25px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: 600;
            width: 100%;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn-register:hover {
            background-color: var(--light-blue);
            transform: translateY(-2px);
        }

        .error-message {
            color: #dc3545;
            background-color: rgba(255, 99, 132, 0.1);
            border: 1px solid #dc3545;
            padding: 10px;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 0.9em;
        }

        .login-link {
            display: block;
            margin-top: 15px;
            color: var(--light-blue);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }

        .login-link:hover {
            color: var(--primary-blue);
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-header">
            <div class="logo"><i class="fas fa-seedling"></i></div>
            <h2>Daftar Akun DryVer</h2>
        </div>
        <form action="register.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" placeholder="Buat username Anda" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="Buat password Anda" required>
            </div>

            <button type="submit" class="btn-register">Daftar Sekarang</button>
        </form>
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>
        <a href="login.php" class="login-link">Sudah punya akun? Login di sini</a>
    </div>
</body>
</html>