<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: auth/login.php');
    exit();
}

include 'config/db.php'; // Perbaikan path

// Periksa koneksi database
if (!isset($conn) || $conn->connect_error) {
    die("Koneksi database gagal: " . ($conn->connect_error ?? "Variabel \$conn tidak terdefinisi."));
}

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=dryver.csv');

// Tambahkan BOM agar Excel bisa baca UTF-8
echo "\xEF\xBB\xBF";

$output = fopen('php://output', 'w');

// Header kolom
fputcsv($output, ['ID', 'Timestamp', 'Temperature (°C)', 'Humidity (%)', 'Status Hujan'], ';');

$query = $conn->query("SELECT id, timestamp, temperature, humidity, raining FROM sensor_data ORDER BY timestamp DESC");

if ($query) {
    while ($row = $query->fetch_assoc()) {
        $rainingStatus = ($row['raining'] == 1) ? 'Hujan' : 'Tidak Hujan';
        fputcsv($output, [
            $row['id'],
            $row['timestamp'],
            $row['temperature'],
            $row['humidity'],
            $rainingStatus
        ], ';');
    }
} else {
    // Jika query error, tulis error ke file
    fputcsv($output, ['Terjadi kesalahan saat mengambil data dari database: ' . $conn->error], ';');
}

fclose($output);
$conn->close();
exit();
?>