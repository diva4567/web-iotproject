<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: auth/login.php');
    exit();
}
include 'config/db.php'; // Pastikan path ini benar (dari root DryVer ke config/db.php)

// Inisialisasi variabel $data untuk mencegah error jika query gagal
$data = null;
$error_message = ''; // Variabel untuk menyimpan pesan error (jika ada)

// Ganti "sensor_data" dengan NAMA TABEL ASLI Anda di database 'dryver_db'
$tableName = "sensor_data"; // PASTIKAN INI SESUAI DENGAN NAMA TABEL DI DATABASE ANDA!

// Tambahkan pengecekan koneksi database sebelum melakukan query
if (!isset($conn) || $conn->connect_error) {
    $error_message = "Koneksi database gagal: " . ($conn->connect_error ?? "Variabel \$conn tidak terdefinisi.");
} else {
    // Tangkap parameter pencarian dari URL
    $search_query = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

    // Ambil data sensor terbaru (LIMIT 1) untuk ditampilkan di kartu dashboard
    $result = $conn->query("SELECT temperature, humidity, raining FROM " . $tableName . " ORDER BY timestamp DESC LIMIT 1");

    if ($result) {
        $data = $result->fetch_assoc();
    } else {
        $error_message = "Gagal mengambil data sensor terbaru: " . $conn->error;
    }
    // Tutup koneksi setelah mengambil data terbaru, karena script history.php akan membuka koneksinya sendiri.
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DryVer | Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        :root {
            --primary-blue: #0A2E49;
            --light-blue: #2A688F;
            --accent-yellow: #B8860B;
            --background-gradient-start: #f0f2f5;
            --background-gradient-end: #e0e2e5;
            --card-background: rgba(255, 255, 255, 0.7); /* Lebih transparan */
            --text-dark: #333;
            --text-light: #fff;
            --border-light: rgba(255, 255, 255, 0.3);
            --shadow-light: rgba(0, 0, 0, 0.08);
            --shadow-strong: rgba(0, 0, 0, 0.15);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start), var(--background-gradient-end));
            margin: 0;
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .dashboard-layout {
            display: flex;
            min-height: calc(100vh - 60px); /* Kurangi tinggi footer */
            flex-grow: 1;
        }

        .sidebar {
            width: 250px;
            background: rgba(255, 255, 255, 0.85); /* Agak transparan */
            backdrop-filter: blur(10px); /* Efek blur */
            padding: 20px 0;
            box-shadow: 2px 0 10px var(--shadow-light);
            display: flex;
            flex-direction: column;
            border-right: 1px solid var(--border-light);
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid var(--border-light);
            margin-bottom: 20px;
        }

        .sidebar-header .logo {
            width: 40px;
            height: 40px;
            background-color: var(--primary-blue);
            color: var(--text-light);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            font-size: 1.5rem;
            margin-right: 10px;
        }

        .sidebar-header h2 {
            margin: 0;
            color: var(--primary-blue);
            font-size: 1.4rem;
            font-weight: 600;
        }

        .sidebar nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar nav ul li {
            margin-bottom: 5px;
        }

        .sidebar nav ul li a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--text-dark);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            border-left: 5px solid transparent;
        }

        .sidebar nav ul li a i {
            margin-right: 15px;
            font-size: 1.1rem;
            color: var(--light-blue);
        }

        .sidebar nav ul li a:hover,
        .sidebar nav ul li a.active {
            background-color: var(--light-blue);
            color: var(--text-light);
            border-left-color: var(--accent-yellow);
        }

        .sidebar nav ul li a:hover i,
        .sidebar nav ul li a.active i {
            color: var(--text-light);
        }

        .sidebar .upgrade-promo {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            padding: 15px;
            margin: 20px;
            box-shadow: 0 4px 10px var(--shadow-light);
            text-align: center;
            border: 1px solid var(--border-light);
            margin-top: auto; /* Push to bottom */
        }

        .sidebar .upgrade-promo img {
            width: 60px;
            margin-bottom: 10px;
        }

        .sidebar .upgrade-promo p {
            font-size: 0.9rem;
            color: var(--text-dark);
            margin-bottom: 15px;
        }

        .sidebar .upgrade-promo a {
            display: inline-block;
            background-color: var(--light-blue);
            color: var(--text-light);
            padding: 8px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.85rem;
            transition: background-color 0.3s ease;
        }

        .sidebar .upgrade-promo a:hover {
            background-color: var(--primary-blue);
        }

        .main-content {
            flex-grow: 1;
            padding: 30px;
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        .navbar {
            background: var(--card-background);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 10px var(--shadow-light);
            border: 1px solid var(--border-light);
        }

        .navbar .search-bar {
            position: relative;
        }

        .navbar .search-bar input {
            padding: 10px 15px 10px 40px;
            border: 1px solid var(--border-light);
            border-radius: 8px;
            font-size: 0.95rem;
            width: 300px;
            background: rgba(255, 255, 255, 0.5);
            color: var(--text-dark);
            transition: all 0.3s ease;
        }

        .navbar .search-bar input::placeholder {
            color: #888;
        }

        .navbar .search-bar input:focus {
            outline: none;
            border-color: var(--light-blue);
            box-shadow: 0 0 0 3px rgba(42, 104, 143, 0.2);
        }

        .navbar .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #888;
        }

        .navbar .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .navbar .user-profile .icon-group {
            display: flex;
            gap: 10px;
        }

        .navbar .user-profile .icon-group i {
            font-size: 1.2rem;
            color: var(--primary-blue);
            cursor: pointer;
            padding: 8px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .navbar .user-profile .icon-group i:hover {
            background-color: var(--light-blue);
            color: var(--text-light);
        }

        .navbar .user-profile .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #ccc; /* Placeholder */
            overflow: hidden;
            border: 2px solid var(--light-blue);
        }

        .navbar .user-profile .avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .navbar .user-profile span {
            font-weight: 600;
            color: var(--text-dark);
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
        }

        .card {
            background: var(--card-background);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 15px var(--shadow-light);
            border: 1px solid var(--border-light);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .card h3 {
            margin-top: 0;
            font-size: 1.1rem;
            color: var(--primary-blue);
            font-weight: 600;
            margin-bottom: 15px;
        }

        .card .value {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--primary-blue);
            margin-bottom: 10px;
        }

        .card .detail {
            font-size: 0.9rem;
            color: #666;
            display: flex;
            align-items: center;
        }

        .card .detail i {
            margin-right: 5px;
            font-size: 1rem;
        }

        .card .detail .indicator {
            display: flex;
            align-items: center;
            font-weight: 600;
            margin-left: 10px;
        }

        .card .detail .indicator.positive {
            color: #28a745; /* Green */
        }

        .card .detail .indicator.negative {
            color: #dc3545; /* Red */
        }

        .card .detail .indicator i {
            margin-right: 3px;
        }

        .card.raining-status {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 30px;
        }

        .card.raining-status .status-icon {
            font-size: 3rem;
            margin-bottom: 15px;
        }

        .card.raining-status .status-text {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-blue);
        }

        .card.raining-status .sub-text {
            font-size: 1rem;
            color: #666;
        }

        .chart-card {
            grid-column: span 2; /* Mengambil 2 kolom untuk grafik */
            padding: 25px;
        }

        .chart-card h3 {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid var(--accent-yellow);
            padding-bottom: 10px;
        }

        #historyChart {
            max-width: 100%;
            height: 350px !important; /* Biarkan Chart.js yang menyesuaikan width */
        }

        .export-button-container {
            text-align: center;
            margin-top: 25px;
        }

        .export-button {
            background-color: var(--primary-blue);
            color: var(--text-light);
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .export-button:hover {
            background-color: var(--light-blue);
            transform: translateY(-2px);
        }

        footer {
            background: linear-gradient(to right, var(--primary-blue), var(--light-blue));
            color: var(--text-light);
            text-align: center;
            padding: 15px 10px;
            font-weight: 500;
            box-shadow: inset 0 2px 5px rgba(0,0,0,0.1);
            font-size: 0.9rem;
            margin-top: auto; /* Push to bottom */
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .dashboard-grid {
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            }
            .chart-card {
                grid-column: 1 / -1; /* Ambil semua kolom */
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                width: 200px;
            }
            .navbar .search-bar input {
                width: 200px;
            }
            .main-content {
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .dashboard-layout {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                border-right: none;
                border-bottom: 1px solid var(--border-light);
                padding-bottom: 0;
            }
            .sidebar nav ul {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                padding: 0 10px;
            }
            .sidebar nav ul li {
                margin-bottom: 0;
            }
            .sidebar nav ul li a {
                padding: 8px 15px;
                border-left: none;
                border-bottom: 3px solid transparent;
            }
            .sidebar nav ul li a:hover,
            .sidebar nav ul li a.active {
                border-left-color: transparent;
                border-bottom-color: var(--accent-yellow);
            }
            .sidebar .upgrade-promo {
                display: none; /* Sembunyikan di mobile agar tidak terlalu ramai */
            }
            .navbar {
                flex-direction: column;
                gap: 15px;
                padding: 15px;
                border-radius: 0;
                box-shadow: 0 2px 8px var(--shadow-light);
            }
            .navbar .search-bar input {
                width: calc(100% - 60px);
                max-width: 300px;
            }
            .navbar .user-profile {
                width: 100%;
                justify-content: center;
            }
            .main-content {
                padding: 15px;
                gap: 20px;
            }
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 480px) {
            header h1 {
                font-size: 1.5rem;
            }
            .navbar .user-profile span {
                display: none; /* Sembunyikan nama di layar kecil */
            }
            .card .value {
                font-size: 1.8rem;
            }
            .card.raining-status .status-icon {
                font-size: 2.5rem;
            }
            .card.raining-status .status-text {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo"><i class="fas fa-seedling"></i></div>
                <h2>DryVer</h2>
            </div>
            <nav>
                <ul>
                    <li><a href="index.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </nav>
            <div class="">
                <p></p>
                <a href=""></a>
            </div>
            <a href="auth/logout.php" class="logout-btn" onclick="return confirm('Apakah kamu yakin ingin logout?')" style="
                background: none;
                border: none;
                color: var(--text-dark);
                text-decoration: none;
                padding: 15px 20px;
                display: flex;
                align-items: center;
                gap: 10px;
                margin-top: 20px;
                font-weight: 500;
                transition: color 0.3s ease;
            "><i class="fas fa-sign-out-alt"></i> Log Out</a>
        </aside>

        <div class="main-content">
            <div class="navbar">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <form action="index.php" method="GET" style="display:inline;">
                        <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($search_query) ?>">
                    </form>
                </div>
                <div class="user-profile">
                    <div class="icon-group">
                        <i class="fas fa-question-circle"></i>
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="avatar"> </div>
                    <span><?= htmlspecialchars($_SESSION['username']) ?></span> </div>
            </div>

            <h1>Dashboard</h1>

            <?php if ($error_message): ?>
                <div class="card" style="grid-column: 1 / -1; background-color: rgba(255, 99, 132, 0.2); border-color: rgba(255, 99, 132, 0.5); text-align: center;">
                    <p style="color: #dc3545; font-weight: 600;"><?= $error_message ?></p>
                </div>
            <?php endif; ?>

            <div class="dashboard-grid">
                <div class="card raining-status">
                    <?php if ($data): ?>
                        <div class="status-icon">
                            <?php if (isset($data['raining']) && $data['raining'] == 1): ?>
                                <i class="fas fa-cloud-showers-heavy" style="color: #6495ED;"></i>
                            <?php else: ?>
                                <i class="fas fa-sun" style="color: #FFD700;"></i>
                            <?php endif; ?>
                        </div>
                        <div class="status-text">
                            <?= (isset($data['raining']) && $data['raining'] == 1) ? 'Hujan' : 'Tidak hujan' ?>
                        </div>
                        <div class="sub-text">Status Hujan Saat Ini</div>
                    <?php else: ?>
                        <div class="status-icon"><i class="fas fa-question-circle" style="color: #ccc;"></i></div>
                        <div class="status-text">N/A</div>
                        <div class="sub-text">Data Status Hujan Belum Tersedia</div>
                    <?php endif; ?>
                </div>

                <div class="card">
                    <h3>Suhu</h3>
                    <?php if ($data && isset($data['temperature'])): ?>
                        <div class="value"><?= htmlspecialchars($data['temperature']) ?> &deg;C</div>
                        <div class="detail"><i class="fas fa-thermometer-half"></i> Suhu saat ini</div>
                    <?php else: ?>
                        <div class="value">N/A</div>
                        <div class="detail"><i class="fas fa-thermometer-half"></i> Suhu belum tersedia</div>
                    <?php endif; ?>
                </div>

                <div class="card">
                    <h3>Kelembapan</h3>
                    <?php if ($data && isset($data['humidity'])): ?>
                        <div class="value"><?= htmlspecialchars($data['humidity']) ?>%</div>
                        <div class="detail"><i class="fas fa-tint"></i> Kelembapan saat ini</div>
                    <?php else: ?>
                        <div class="value">N/A</div>
                        <div class="detail"><i class="fas fa-tint"></i> Kelembapan belum tersedia</div>
                    <?php endif; ?>
                </div>

                <div class="card chart-card">
                    <h3>Grafik Riwayat Data</h3>
                    <canvas id="historyChart"></canvas>
                    <div class="export-button-container">
                        <form action="export.php" method="post">
                            <button type="submit" class="export-button"><i class="fas fa-file-excel"></i> Export ke Excel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        &copy; <?= date("Y") ?> DryVer Monitoring System
    </footer>

    <script>
        // Fungsi untuk mengambil data riwayat (akan memanggil API)
        function fetchHistoryData(searchTerm = '') {
            let url = 'api/history.php'; // Panggil file history.php yang sudah diubah ke JSON
            if (searchTerm) {
                // Jika ada search term, tambahkan sebagai parameter ke API
                url += '?search=' + encodeURIComponent(searchTerm);
            }

            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        console.error('Network response was not ok:', response.statusText);
                        if (response.status === 401) {
                            alert('Sesi berakhir atau tidak terotorisasi. Silakan login kembali.');
                            window.location.href = 'auth/login.php';
                        }
                        throw new Error('Network response was not ok.');
                    }
                    return response.json(); // Menguraikan respons sebagai JSON
                })
                .then(responseData => {
                    if (responseData.status === "success" && Array.isArray(responseData.data)) {
                        const data = responseData.data;
                        // Map data untuk grafik
                        const labels = data.map(item => new Date(item.timestamp).toLocaleString('id-ID', {
                            year: 'numeric', month: 'short', day: 'numeric',
                            hour: '2-digit', minute: '2-digit', second: '2-digit'
                        }));
                        const temperatures = data.map(item => item.temperature);
                        const humidities = data.map(item => item.humidity);

                        const ctx = document.getElementById('historyChart').getContext('2d');

                        // Cek apakah ada Chart instance yang sudah ada, hancurkan jika ada
                        if (window.myChart) {
                            window.myChart.destroy();
                        }

                        window.myChart = new Chart(ctx, {
                            type: 'line',
                            data: {
                                labels: labels,
                                datasets: [
                                    {
                                        label: 'Suhu (°C)',
                                        data: temperatures,
                                        borderColor: '#FF6384',
                                        backgroundColor: 'rgba(255, 99, 132, 0.1)',
                                        borderWidth: 2,
                                        fill: true,
                                        tension: 0.4,
                                        pointBackgroundColor: '#FF6384',
                                        pointBorderColor: '#fff',
                                        pointHoverBackgroundColor: '#fff',
                                        pointHoverBorderColor: '#FF6384'
                                    },
                                    {
                                        label: 'Kelembapan (%)',
                                        data: humidities,
                                        borderColor: '#36A2EB',
                                        backgroundColor: 'rgba(54, 162, 235, 0.1)',
                                        borderWidth: 2,
                                        fill: true,
                                        tension: 0.4,
                                        pointBackgroundColor: '#36A2EB',
                                        pointBorderColor: '#fff',
                                        pointHoverBackgroundColor: '#fff',
                                        pointHoverBorderColor: '#36A2EB'
                                    }
                                ]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: {
                                        display: true,
                                        position: 'top',
                                        labels: {
                                            font: {
                                                family: 'Poppins'
                                            }
                                        }
                                    },
                                    tooltip: {
                                        callbacks: {
                                            title: function(context) {
                                                return 'Waktu: ' + context[0].label;
                                            },
                                            label: function(context) {
                                                let label = context.dataset.label || '';
                                                if (label) {
                                                    label += ': ';
                                                }
                                                if (context.parsed.y !== null) {
                                                    label += context.parsed.y + (context.dataset.label.includes('Suhu') ? ' °C' : '%');
                                                }
                                                return label;
                                            }
                                        },
                                        bodyFont: {
                                            family: 'Poppins'
                                        },
                                        titleFont: {
                                            family: 'Poppins',
                                            weight: 'bold'
                                        }
                                    }
                                },
                                scales: {
                                    x: {
                                        display: true,
                                        title: {
                                            display: true,
                                            text: 'Waktu',
                                            font: {
                                                family: 'Poppins',
                                                weight: 'bold'
                                            }
                                        },
                                        grid: {
                                            display: false
                                        },
                                        ticks: {
                                            font: {
                                                family: 'Poppins'
                                            }
                                        }
                                    },
                                    y: {
                                        display: true,
                                        title: {
                                            display: true,
                                            text: 'Nilai',
                                            font: {
                                                family: 'Poppins',
                                                weight: 'bold'
                                            }
                                        },
                                        grid: {
                                            color: 'rgba(0, 0, 0, 0.05)'
                                        },
                                        ticks: {
                                            font: {
                                                family: 'Poppins'
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    } else if (responseData.error) {
                        console.error('API Error:', responseData.error);
                        alert('Error saat mengambil data riwayat: ' + responseData.error);
                    } else {
                        console.error('Unexpected API response structure:', responseData);
                        alert('Struktur data riwayat tidak sesuai atau kosong.');
                    }
                })
                .catch(error => {
                    console.error('Error fetching history data:', error);
                    alert('Terjadi kesalahan saat mengambil data riwayat.');
                });
        }

        // Panggil fungsi saat halaman dimuat
        document.addEventListener('DOMContentLoaded', () => {
            // Ambil search term dari URL saat ini (jika ada)
            const urlParams = new URLSearchParams(window.location.search);
            const initialSearch = urlParams.get('search') || '';
            fetchHistoryData(initialSearch); // Panggil untuk memuat grafik
        });
    </script>
</body>
</html>