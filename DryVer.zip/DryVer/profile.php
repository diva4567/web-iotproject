<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: auth/login.php');
    exit();
}

include 'config/db.php'; 

$user_data = null;
$error_message = '';

if (!isset($conn) || $conn->connect_error) {
    $error_message = "Koneksi database gagal: " . ($conn->connect_error ?? "Variabel \$conn tidak terdefinisi.");
} else {
    $username = $_SESSION['username'];
    $stmt = $conn->prepare("SELECT username FROM users WHERE username = ?");

    if ($stmt) {
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $user_data = $result->fetch_assoc();
        } else {
            $error_message = "Data pengguna tidak ditemukan.";
        }
        $stmt->close();
    } else {
        $error_message = "Gagal menyiapkan statement: " . $conn->error;
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DryVer | Profil Pengguna</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        :root {
            --primary-blue: #0A2E49;
            --light-blue: #2A688F;
            --accent-yellow: #B8860B;
            --background-gradient-start: #f0f2f5;
            --background-gradient-end: #e0e2e5;
            --card-background: rgba(255, 255, 255, 0.7);
            --text-dark: #333;
            --text-light: #fff;
            --border-light: rgba(255, 255, 255, 0.3);
            --shadow-light: rgba(0, 0, 0, 0.08);
            --shadow-strong: rgba(0, 0, 0, 0.15);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--background-gradient-start), var(--background-gradient-end));
            margin: 0;
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .dashboard-layout {
            display: flex;
            min-height: calc(100vh - 60px);
            flex-grow: 1;
        }

        .sidebar {
            width: 250px;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(10px);
            padding: 20px 0;
            box-shadow: 2px 0 10px var(--shadow-light);
            display: flex;
            flex-direction: column;
            border-right: 1px solid var(--border-light);
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid var(--border-light);
            margin-bottom: 20px;
        }

        .sidebar-header .logo {
            width: 40px;
            height: 40px;
            background-color: var(--primary-blue);
            color: var(--text-light);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            font-size: 1.5rem;
            margin-right: 10px;
        }

        .sidebar-header h2 {
            margin: 0;
            color: var(--primary-blue);
            font-size: 1.4rem;
            font-weight: 600;
        }

        .sidebar nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar nav ul li {
            margin-bottom: 5px;
        }

        .sidebar nav ul li a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--text-dark);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            border-left: 5px solid transparent;
        }

        .sidebar nav ul li a i {
            margin-right: 15px;
            font-size: 1.1rem;
            color: var(--light-blue);
        }

        .sidebar nav ul li a:hover,
        .sidebar nav ul li a.active {
            background-color: var(--light-blue);
            color: var(--text-light);
            border-left-color: var(--accent-yellow);
        }

        .sidebar nav ul li a:hover i,
        .sidebar nav ul li a.active i {
            color: var(--text-light);
        }

        .sidebar .upgrade-promo {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            padding: 15px;
            margin: 20px;
            box-shadow: 0 4px 10px var(--shadow-light);
            text-align: center;
            border: 1px solid var(--border-light);
            margin-top: auto;
        }

        .sidebar .upgrade-promo img {
            width: 60px;
            margin-bottom: 10px;
        }

        .sidebar .upgrade-promo p {
            font-size: 0.9rem;
            color: var(--text-dark);
            margin-bottom: 15px;
        }

        .sidebar .upgrade-promo a {
            display: inline-block;
            background-color: var(--light-blue);
            color: var(--text-light);
            padding: 8px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.85rem;
            transition: background-color 0.3s ease;
        }

        .sidebar .upgrade-promo a:hover {
            background-color: var(--primary-blue);
        }

        .main-content {
            flex-grow: 1;
            padding: 30px;
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        .navbar {
            background: var(--card-background);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 10px var(--shadow-light);
            border: 1px solid var(--border-light);
        }

        .navbar .search-bar {
            position: relative;
        }

        .navbar .search-bar input {
            padding: 10px 15px 10px 40px;
            border: 1px solid var(--border-light);
            border-radius: 8px;
            font-size: 0.95rem;
            width: 300px;
            background: rgba(255, 255, 255, 0.5);
            color: var(--text-dark);
            transition: all 0.3s ease;
        }

        .navbar .search-bar input::placeholder {
            color: #888;
        }

        .navbar .search-bar input:focus {
            outline: none;
            border-color: var(--light-blue);
            box-shadow: 0 0 0 3px rgba(42, 104, 143, 0.2);
        }

        .navbar .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #888;
        }

        .navbar .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .navbar .user-profile .icon-group {
            display: flex;
            gap: 10px;
        }

        .navbar .user-profile .icon-group i {
            font-size: 1.2rem;
            color: var(--primary-blue);
            cursor: pointer;
            padding: 8px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .navbar .user-profile .icon-group i:hover {
            background-color: var(--light-blue);
            color: var(--text-light);
        }

        .navbar .user-profile .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #ccc;
            overflow: hidden;
            border: 2px solid var(--light-blue);
        }

        .navbar .user-profile .avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .navbar .user-profile span {
            font-weight: 600;
            color: var(--text-dark);
        }

        .profile-container {
            background: var(--card-background);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 15px var(--shadow-light);
            border: 1px solid var(--border-light);
            max-width: 700px;
            margin: 30px auto; /* Tengahkan */
            text-align: left;
        }

        .profile-container h2 {
            color: var(--primary-blue);
            margin-top: 0;
            margin-bottom: 25px;
            border-bottom: 2px solid var(--accent-yellow);
            padding-bottom: 10px;
        }

        .profile-info p {
            font-size: 1.1rem;
            margin-bottom: 15px;
            color: var(--text-dark);
        }

        .profile-info p strong {
            color: var(--primary-blue);
            margin-right: 10px;
            display: inline-block;
            min-width: 120px;
        }

        .profile-info .avatar-profile {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background-color: #ccc;
            margin: 0 auto 25px;
            display: block;
            border: 4px solid var(--light-blue);
            overflow: hidden;
        }

        .profile-info .avatar-profile i {
            font-size: 4rem;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            background-color: var(--light-blue);
        }
        .profile-info .avatar-profile img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Hapus atau nonaktifkan CSS untuk .profile-actions jika tombol tidak ada */
        .profile-actions {
            display: none; /* Menyembunyikan seluruh div actions */
        }


        footer {
            background: linear-gradient(to right, var(--primary-blue), var(--light-blue));
            color: var(--text-light);
            text-align: center;
            padding: 15px 10px;
            font-weight: 500;
            box-shadow: inset 0 2px 5px rgba(0,0,0,0.1);
            font-size: 0.9rem;
            margin-top: auto;
        }

        /* Responsive Design for Profile Page */
        @media (max-width: 768px) {
            .profile-container {
                margin: 20px;
                padding: 20px;
            }
            .profile-info p {
                font-size: 1rem;
            }
            .profile-info p strong {
                min-width: 90px;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo"><i class="fas fa-seedling"></i></div>
                <h2>DryVer</h2>
            </div>
            <nav>
                <ul>
                    <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="profile.php" class="active"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </nav>
            <div class="">
                <p></p>
                <a href="#"></a>
            </div>
            <a href="auth/logout.php" class="logout-btn" onclick="return confirm('Apakah kamu yakin ingin logout?')" style="
                background: none;
                border: none;
                color: var(--text-dark);
                text-decoration: none;
                padding: 15px 20px;
                display: flex;
                align-items: center;
                gap: 10px;
                margin-top: 20px;
                font-weight: 500;
                transition: color 0.3s ease;
            "><i class="fas fa-sign-out-alt"></i> Log Out</a>
        </aside>

        <div class="main-content">
            <h1>Profil Pengguna</h1>

            <?php if ($error_message): ?>
                <div class="card" style="background-color: rgba(255, 99, 132, 0.2); border-color: rgba(255, 99, 132, 0.5); text-align: center; margin: 20px auto;">
                    <p style="color: #dc3545; font-weight: 600;"><?= $error_message ?></p>
                </div>
            <?php endif; ?>

            <div class="profile-container">
                <h2>Informasi Profil</h2>
                <?php if ($user_data): ?>
                    <div class="profile-info">
                        <div class="avatar-profile">
                            <i class="fas fa-user-alt"></i>
                            </div>
                        <p><strong>Username:</strong> <?= htmlspecialchars($user_data['username']) ?></p>
                        </div>
                    <?php else: ?>
                    <p style="text-align: center;">Tidak dapat memuat informasi profil. Silakan coba lagi nanti.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <footer>
        &copy; <?= date("Y") ?> DryVer Monitoring System
    </footer>
</body>
</html>