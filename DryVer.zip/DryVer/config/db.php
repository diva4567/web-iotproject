<?php
$servername = "localhost"; // Ganti jika server database Anda berbeda
$username = "root";      // Ganti dengan username database Anda
$password = "";          // Ganti dengan password database Anda
$dbname = "dryver_db";   // Ganti dengan nama database Anda

// Buat koneksi dengan charset utf8mb4 untuk support semua karakter
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8mb4");

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>