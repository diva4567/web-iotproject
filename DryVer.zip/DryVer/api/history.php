<?php
session_start();
// Penting: Memberitahu browser/client bahwa respons ini adalah JSON
header('Content-Type: application/json');

if (!isset($_SESSION['username'])) {
    // Jika tidak ada sesi, kirim respons JSON error dan status HTTP 401
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized: Please log in.']);
    exit();
}

include __DIR__ . '/../config/db.php'; // Menggunakan __DIR__ untuk path relatif yang lebih aman

$response = [
    'status' => 'error',
    'message' => 'Terjadi kesalahan tidak dikenal.',
    'data' => []
];

// Periksa koneksi database sebelum melakukan query
if (!isset($conn) || $conn->connect_error) {
    $response['message'] = "Koneksi database gagal: " . ($conn->connect_error ?? "Variabel \$conn tidak terdefinisi.");
    echo json_encode($response);
    exit();
}

// Ganti "sensor_data" dengan NAMA TABEL ASLI Anda di database 'dryver_db'
// Berdasarkan gambar yang Anda berikan, 'sensor_data' adalah nama tabel yang tepat.
$tableName = "sensor_data"; // PASTIKAN INI SESUAI DENGAN NAMA TABEL DI DATABASE ANDA!

// Tangkap parameter pencarian dari URL (jika ada)
$search_query = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// Query untuk mengambil semua data yang relevan untuk grafik
// Urutkan berdasarkan timestamp secara ASC (ascending) agar grafik berjalan dari kiri ke kanan sesuai waktu
$sql = "SELECT timestamp, temperature, humidity FROM " . $tableName;

$where_clauses = [];
if (!empty($search_query)) {
    // Menambahkan kondisi pencarian jika ada.
    // Anda bisa menyesuaikan kolom yang ingin dicari. Contoh:
    $where_clauses[] = "(timestamp LIKE '%$search_query%' OR temperature LIKE '%$search_query%' OR humidity LIKE '%$search_query%')";
}

if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

$sql .= " ORDER BY timestamp ASC";

// Opsional: Batasi jumlah data jika riwayat sangat panjang untuk performa grafik
// $sql .= " LIMIT 100"; // Contoh: Ambil 100 data terakhir

$result = $conn->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        $data_array = [];
        while($row = $result->fetch_assoc()) {
            $data_array[] = $row;
        }
        $response['status'] = 'success';
        $response['message'] = 'Data riwayat berhasil diambil.';
        $response['data'] = $data_array;
    } else {
        $response['status'] = 'success'; // Tetap sukses meskipun tidak ada data
        $response['message'] = 'Tidak ada data riwayat sensor ditemukan.';
        $response['data'] = []; // Kirim array kosong
    }
} else {
    $response['message'] = "Gagal mengambil data riwayat sensor: " . $conn->error;
}

$conn->close();

echo json_encode($response);
?>