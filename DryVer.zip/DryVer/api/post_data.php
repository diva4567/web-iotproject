<?php
include '../config/db.php';
header('Content-Type: application/json');

// Validasi input
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Method not allowed"]);
    exit();
}

// Ambil data dari POST
$data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!isset($data['temperature']) || !isset($data['humidity']) || !isset($data['raining'])) {
    echo json_encode(["status" => "error", "message" => "Data tidak lengkap"]);
    exit();
}

// Sanitasi data
$temperature = filter_var($data['temperature'], FILTER_VALIDATE_FLOAT);
$humidity = filter_var($data['humidity'], FILTER_VALIDATE_FLOAT);
$raining = filter_var($data['raining'], FILTER_VALIDATE_INT);

if ($temperature === false || $humidity === false || $raining === false) {
    echo json_encode(["status" => "error", "message" => "Data tidak valid"]);
    exit();
}

if (!isset($conn)) {
    echo json_encode(["status" => "error", "message" => "Koneksi database tidak tersedia"]);
    exit();
}

$stmt = $conn->prepare("INSERT INTO sensor_data (temperature, humidity, raining) VALUES (?, ?, ?)");

if ($stmt === false) {
    echo json_encode(["status" => "error", "message" => "Gagal menyiapkan pernyataan: " . $conn->error]);
    exit();
}

$stmt->bind_param("ddi", $temperature, $humidity, $raining);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Data berhasil disimpan"]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal menyimpan data: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>