#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>
#include <ESP32Servo.h>

// WiFi Configuration
const char* ssid = "Rumah Kayu";
const char* password = "galunggung2";
const char* serverName = "http://192.168.1.8:8000/api/post_data.php";

// Pin Configuration
#define DHT_PIN 4            // Ubah pin DHT ke GPIO 4
#define DHT_TYPE DHT22
#define RAIN_SENSOR_PIN 34   // Biarkan sensor hujan tetap di GPIO 34
#define SERVO_PIN 13

// Servo Configuration
const int SERVO_CLOSED_ANGLE = 0;
const int SERVO_OPEN_ANGLE = 90;

// Timing Configuration
const long interval = 5000;
unsigned long previousMillis = 0;

// Sensor Objects
DHT dht(DHT_PIN, DHT_TYPE);
Servo myServo;

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 5000) {
    ; // Menunggu koneksi serial
  }
  Serial.println("System Initializing...");

  // Inisialisasi sensor dan aktuator
  pinMode(RAIN_SENSOR_PIN, INPUT);
  myServo.setPeriodHertz(50);
  myServo.attach(SERVO_PIN, 500, 2400);
  myServo.write(SERVO_OPEN_ANGLE);
  
  dht.begin();

  // Koneksi WiFi
  WiFi.begin(ssid, password);
  Serial.println("Connecting to WiFi...");
  unsigned long startTime = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startTime < 20000) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nConnected to WiFi");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nFailed to connect to WiFi");
  }
}

void loop() {
  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;

    // Baca sensor
    float temperature = dht.readTemperature();
    float humidity = dht.readHumidity();
    int rainStatus = digitalRead(RAIN_SENSOR_PIN) == LOW ? 1 : 0;

    // Validasi pembacaan DHT
    if (isnan(temperature) || isnan(humidity)) {
      Serial.println("Failed to read from DHT sensor!");
      return;
    }

    // Kontrol servo
    if (rainStatus == 1) {
      myServo.write(SERVO_CLOSED_ANGLE);
      Serial.println("Rain detected - Closing cover");
    } else {
      myServo.write(SERVO_OPEN_ANGLE);
      Serial.println("No rain - Opening cover");
    }

    // Cetak data ke Serial Monitor
    Serial.printf("Temperature: %.2f°C, Humidity: %.2f%%, Rain: %s\n",
                  temperature, humidity, rainStatus ? "Yes" : "No");

    // Kirim data ke server jika WiFi tersambung
    if (WiFi.status() == WL_CONNECTED) {
      HTTPClient http;
      http.begin(serverName);
      http.addHeader("Content-Type", "application/x-www-form-urlencoded");

      String postData = "temperature=" + String(temperature) +
                        "&humidity=" + String(humidity) +
                        "&raining=" + String(rainStatus);

      int httpCode = http.POST(postData);

      if (httpCode == HTTP_CODE_OK) {
        Serial.println("Data sent successfully");
      } else {
        Serial.printf("HTTP error: %s\n", http.errorToString(httpCode).c_str());
      }

      http.end();
    }
  }
}
